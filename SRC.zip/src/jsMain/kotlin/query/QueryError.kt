package query

external interface QueryError